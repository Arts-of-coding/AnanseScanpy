# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['anansescanpy']

package_data = \
{'': ['*']}

install_requires = \
['anndata>=0.8.0,<0.9.0',
 'jupyterlab>=3.3.4,<4.0.0',
 'matplotlib>=3.5.3,<4.0.0',
 'numba>=0.56.3,<0.57.0',
 'numpy>=1.23.3,<2.0.0',
 'pandas>=1.4.4,<2.0.0',
 'pip>=22.2.2,<23.0.0',
 'scanpy>=1.9.1,<2.0.0',
 'scipy>=1.9.1,<2.0.0']

setup_kwargs = {
    'name': 'anansescanpy',
    'version': '0.1.0',
    'description': 'implementation of scANANSE for scanpy objects in Python',
    'long_description': '',
    'author': 'J Arts (Arts-of-coding)',
    'author_email': 'julian.armando.arts@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Arts-of-coding/AnanseScanpy',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
